#include "common.h"
#include "PowerPoints.h"

// Some cut beta feature

void CPowerPoint::Update()
{}

void CPowerPoints::Init()
{}

void CPowerPoints::Update()
{}

void CPowerPoints::GenerateNewOne(float, float, float, float, float, float, uint8)
{}

void CPowerPoints::Save(uint8**, uint32*)
{}

void CPowerPoints::Load(uint8*, uint32)
{}