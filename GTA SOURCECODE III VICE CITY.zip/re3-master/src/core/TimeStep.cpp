#include "TimeStep.h"

float CTimeStep::ms_fTimeScale = 1.0f;
float CTimeStep::ms_fFramesPerUpdate = 1.0f;
float CTimeStep::ms_fTimeStep = 1.0f;
