#pragma once

RwImage *RtPNGImageWrite(RwImage * image, const RwChar * imageName);
RwImage *RtPNGImageRead(const RwChar * imageName);
