#pragma once

#include "Object.h"

class CProjectile : public CObject
{
public:
	CProjectile(int32);
};
